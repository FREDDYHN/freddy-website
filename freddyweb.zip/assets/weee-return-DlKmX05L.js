const s="/assets/weee-return-Baww72Ls.png";export{s as _};
