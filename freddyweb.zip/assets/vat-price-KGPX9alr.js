import{_ as z,u as D,r as _,e as H,w as S,c as l,o as c,a as e,t as d,b as m,d as E}from"./index-wYayREmB.js";import{l as L}from"./index-Bi72t57e.js";const T={class:"vat-price-page"},$={class:"price-content"},A={class:"price-scroll"},F={class:"price-body"},I={key:0,class:"loading"},N=["innerHTML"],q={class:"footer"},C={__name:"vat-price",setup(O){const g=E(),{t:o,locale:p}=D(),r=_(""),i=_(!0);function y(t){const a={zh:"vat-price-zh",en:"vat-price-en",de:"vat-price-de"};return a[t]||a.zh}async function b(t){i.value=!0,r.value="";const a=y(t),x=`${window.location.origin}/templates/${a}.docx`;try{const B=await(await fetch(x)).arrayBuffer(),n=await L.convertToHtml({arrayBuffer:B,includeDefaultStyleMap:!0});let s=n.value;try{const h=new DOMParser().parseFromString(n.value,"text/html"),P=Array.from(h.querySelectorAll("img")),u=new Set;P.forEach(v=>{const f=v.getAttribute("src")||"";u.has(f)?v.remove():u.add(f)}),s=h.body.innerHTML}catch{s=n.value}r.value=`
      <style>
        .mammoth-table-bordered {
          width: 100%;
          overflow-x: auto;
          -webkit-overflow-scrolling: touch;
          box-sizing: border-box;
          font-family: inherit;
          color: #222;
        }
        .mammoth-table-bordered table {
          width: 100% !important;
          table-layout: fixed !important;
          border-collapse: collapse !important;
          border-spacing: 0 !important;
        }
        .mammoth-table-bordered th,
        .mammoth-table-bordered td {
          border: 1px solid #e6e6e6 !important;
          padding: 10px !important;
          vertical-align: top !important;
          word-break: break-word !important;
          hyphens: auto !important;
          box-sizing: border-box !important;
        }
        .mammoth-table-bordered th {
          background: #fafafa !important;
          font-weight: 600 !important;
          text-align: left !important;
        }
        .mammoth-table-bordered td img,
        .mammoth-table-bordered th img {
          max-width: 100% !important;
          height: auto !important;
          display: block !important;
        }
        .mammoth-table-bordered td p,
        .mammoth-table-bordered th p {
          margin: 0 !important;
        }
        .mammoth-table-bordered h1,
        .mammoth-table-bordered h2,
        .mammoth-table-bordered h3 {
          margin: 0 0 12px 0 !important;
        }
      </style>
      <div class="mammoth-table-bordered">${s}</div>
    `}catch{r.value=`<div style="color:red">${o("vatPrice.load_failed")}</div>`}finally{i.value=!1}}H(()=>{b(p.value)}),S(p,t=>{b(t)});const w=()=>{g.back()};return(t,a)=>(c(),l("div",T,[e("div",$,[e("div",A,[e("h2",null,d(m(o)("vatPrice.title")),1),e("div",F,[i.value?(c(),l("div",I,d(m(o)("vatPrice.loading")),1)):(c(),l("div",{key:1,innerHTML:r.value},null,8,N))])]),e("div",q,[e("button",{class:"back-btn",onClick:w},d(m(o)("vatPrice.back_button")),1)])])]))}},V=z(C,[["__scopeId","data-v-1918844d"]]);export{V as default};
