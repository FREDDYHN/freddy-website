import{_ as u,r as l,e as v,c as s,o as a,a as t,d as m}from"./index-wYayREmB.js";import{l as _}from"./index-Bi72t57e.js";const f={class:"contract-preview-page"},h={class:"contract-content"},y={class:"contract-scroll"},x={class:"contract-body"},w={key:0,class:"loading"},b=["innerHTML"],g={__name:"contract-preview",setup(k){const r=m(),o=l(""),n=l(!0),i=`${window.location.origin}/templates/vat-template.docx`;v(async()=>{try{const e=await(await fetch(i)).arrayBuffer(),p=await _.convertToHtml({arrayBuffer:e,includeDefaultStyleMap:!0});o.value=`
      <style>
        .mammoth-content table {
          width: 100%;
          border-collapse: collapse;
        }
        .mammoth-content th, .mammoth-content td {
          border: 1px solid #222;
          padding: 6px 10px;
          vertical-align: top;
        }
      </style>
      <div class="mammoth-content">${p.value}</div>
    `}catch{o.value='<div style="color:red">合同内容加载失败</div>'}finally{n.value=!1}});const d=()=>{r.push("/contract-sign")};return(c,e)=>(a(),s("div",f,[t("div",h,[t("div",y,[e[0]||(e[0]=t("h2",null,"合同内容预览",-1)),t("div",x,[n.value?(a(),s("div",w,"正在加载合同内容…")):(a(),s("div",{key:1,innerHTML:o.value},null,8,b))])]),t("div",{class:"footer"},[t("button",{class:"next-btn",onClick:d},"我已阅读并同意合同内容")])])]))}},H=u(g,[["__scopeId","data-v-5de0b578"]]);export{H as default};
