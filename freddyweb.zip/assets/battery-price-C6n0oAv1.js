import{_ as g,u as x,r as b,e as w,w as k,c as n,o as l,a as e,t as s,b as c,d as B}from"./index-wYayREmB.js";import{l as z}from"./index-Bi72t57e.js";const P={class:"battery-price-page"},D={class:"price-content"},M={class:"price-scroll"},$={class:"price-body"},H={key:0,class:"loading"},L=["innerHTML"],T={class:"footer"},E={__name:"battery-price",setup(F){const p=B(),{t:o,locale:d}=x(),r=b(""),i=b(!0);function h(t){const a={zh:"battery-price-zh",en:"battery-price-en",de:"battery-price-de"};return a[t]||a.zh}async function m(t){i.value=!0,r.value="";const a=h(t),f=`${window.location.origin}/templates/${a}.docx`;try{const y=await(await fetch(f)).arrayBuffer(),v=await z.convertToHtml({arrayBuffer:y,includeDefaultStyleMap:!0});r.value=`
      <style>
        .mammoth-table-bordered {
          width: 100%;
          overflow-x: auto;
          -webkit-overflow-scrolling: touch;
          box-sizing: border-box;
          font-family: inherit;
          color: #222;
        }
        .mammoth-table-bordered table {
          width: 100% !important;
          table-layout: fixed !important;
          border-collapse: collapse !important;
          border-spacing: 0 !important;
        }
        .mammoth-table-bordered th,
        .mammoth-table-bordered td {
          border: 1px solid #e6e6e6 !important;
          padding: 10px !important;
          vertical-align: top !important;
          word-break: break-word !important;
          hyphens: auto !important;
          box-sizing: border-box !important;
        }
        .mammoth-table-bordered th {
          background: #fafafa !important;
          font-weight: 600 !important;
          text-align: left !important;
        }
        .mammoth-table-bordered td img,
        .mammoth-table-bordered th img {
          max-width: 100% !important;
          height: auto !important;
          display: block !important;
        }
        .mammoth-table-bordered td p,
        .mammoth-table-bordered th p {
          margin: 0 !important;
        }
        .mammoth-table-bordered h1,
        .mammoth-table-bordered h2,
        .mammoth-table-bordered h3 {
          margin: 0 0 12px 0 !important;
        }
      </style>
      <div class="mammoth-table-bordered">${v.value}</div>
    `}catch{r.value=`<div style="color:red">${o("batteryPrice.load_failed")}</div>`}finally{i.value=!1}}w(()=>{m(d.value)}),k(d,t=>{m(t)});const u=()=>{p.back()};return(t,a)=>(l(),n("div",P,[e("div",D,[e("div",M,[e("h2",null,s(c(o)("batteryPrice.title")),1),e("div",$,[i.value?(l(),n("div",H,s(c(o)("batteryPrice.loading")),1)):(l(),n("div",{key:1,innerHTML:r.value},null,8,L))])]),e("div",T,[e("button",{class:"back-btn",onClick:u},s(c(o)("batteryPrice.back_button")),1)])])]))}},S=g(E,[["__scopeId","data-v-59fdd42c"]]);export{S as default};
