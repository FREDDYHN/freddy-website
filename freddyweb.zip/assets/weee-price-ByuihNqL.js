import{_ as g,u as v,r as b,e as k,w as x,c as l,o as s,a as t,t as c,b as d,d as y}from"./index-wYayREmB.js";import{l as B}from"./index-Bi72t57e.js";const M={class:"weee-price-page"},P={class:"price-content"},z={class:"price-scroll"},T={class:"price-body"},$={key:0,class:"loading"},D=["innerHTML"],H={class:"footer"},E={__name:"weee-price",setup(I){const h=y(),{t:o,locale:m}=v(),a=b(""),r=b(!0),u=e=>({zh:"weee-price-zh",en:"weee-price-en",de:"weee-price-de"})[e]||"weee-price-zh",p=async()=>{try{r.value=!0;const e=u(m.value),i=`${window.location.origin}/templates/${e}.docx`,n=await fetch(i);if(!n.ok)throw new Error(`HTTP error! status: ${n.status}`);const w=await n.arrayBuffer(),_=await B.convertToHtml({arrayBuffer:w,includeDefaultStyleMap:!0});a.value=`
      <style>
        /* Improve table rendering from mammoth output */
        .mammoth-table-bordered {
          width: 100%;
          overflow-x: auto;
          -webkit-overflow-scrolling: touch;
          box-sizing: border-box;
          font-family: inherit;
          color: #222;
        }
        .mammoth-table-bordered table {
          width: 100% !important;
          table-layout: fixed !important; /* make columns consistent */
          border-collapse: collapse !important;
          border-spacing: 0 !important;
        }
        .mammoth-table-bordered th,
        .mammoth-table-bordered td {
          border: 1px solid #e6e6e6 !important;
          padding: 10px !important;
          vertical-align: top !important;
          word-break: break-word !important;
          hyphens: auto !important;
          box-sizing: border-box !important;
        }
        .mammoth-table-bordered th {
          background: #fafafa !important;
          font-weight: 600 !important;
          text-align: left !important;
        }
        .mammoth-table-bordered td img,
        .mammoth-table-bordered th img {
          max-width: 100% !important;
          height: auto !important;
          display: block !important;
        }
        /* allow long content cells to wrap and keep rows similar height */
        .mammoth-table-bordered td p,
        .mammoth-table-bordered th p {
          margin: 0 !important;
        }
        /* ensure headings and paragraphs from mammoth have consistent spacing */
        .mammoth-table-bordered h1,
        .mammoth-table-bordered h2,
        .mammoth-table-bordered h3 {
          margin: 0 0 12px 0 !important;
        }
      </style>
      <div class="mammoth-table-bordered">${_.value}</div>
    `}catch(e){console.error("Failed to load document:",e),a.value=`<div style="color:red">${o("weePrice.load_failed")}</div>`}finally{r.value=!1}};k(()=>{p()}),x(m,()=>{p()});const f=()=>{h.back()};return(e,i)=>(s(),l("div",M,[t("div",P,[t("div",z,[t("h2",null,c(d(o)("weePrice.title")),1),t("div",T,[r.value?(s(),l("div",$,c(d(o)("weePrice.loading")),1)):(s(),l("div",{key:1,innerHTML:a.value},null,8,D))])]),t("div",H,[t("button",{class:"back-btn",onClick:f},c(d(o)("weePrice.back_button")),1)])])]))}},L=g(E,[["__scopeId","data-v-9111bbb0"]]);export{L as default};
